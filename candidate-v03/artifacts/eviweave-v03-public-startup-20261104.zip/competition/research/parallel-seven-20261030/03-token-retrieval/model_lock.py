"""Atomic directory ownership. No stale-lock stealing or third-party cleanup."""
import json
import os
from pathlib import Path
import socket
import uuid
from datetime import datetime,timezone

RUN=Path(__file__).resolve().parent
LOCK=RUN.parent/'local-model.lock'


class ModelLock:
    def __enter__(self):
        self.token=uuid.uuid4().hex
        try:
            LOCK.mkdir()
        except FileExistsError:
            raise RuntimeError('Public local-model.lock is held; continue CPU work, never steal it')
        self.owner=dict(token=self.token,pid=os.getpid(),host=socket.gethostname(),
                        run=str(RUN),direction='03-token-retrieval',created_utc=datetime.now(timezone.utc).isoformat())
        (LOCK/'owner.json').write_text(json.dumps(self.owner,indent=2),encoding='utf-8')
        return self

    def assert_owned(self):
        owner=json.loads((LOCK/'owner.json').read_text(encoding='utf-8'))
        if owner.get('token')!=self.token or owner.get('pid')!=os.getpid():
            raise RuntimeError('GPU lock ownership changed')

    def __exit__(self,*args):
        self.assert_owned()
        (LOCK/'owner.json').unlink()
        LOCK.rmdir()
