"""Frozen final-step-only source training/validation; parent holds public lock."""
import argparse
from collections import Counter
from datetime import datetime,timezone
import gc
import hashlib
import json
import os
from pathlib import Path
import sys
import time

os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',
                  OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',CUBLAS_WORKSPACE_CONFIG=':4096:8')
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
ROOT=BASE.parents[3]
sys.path.insert(0,str(ROOT/'models/qwen35_runtime'))
import numpy as np
import torch
from metric_model import MetricEncoder,check_lock,score_one,positive_loss,sha,BASE_SHA,FEATURES
from metrics import summarize_case,aggregate,qualification,METRICS


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def save(p,value):
    with p.open('x',encoding='utf-8') as f:
        json.dump(value,f,ensure_ascii=False,indent=2)
        f.write('\n')


def verify(recipe):
    for rel,expected in recipe['dependencies_sha256'].items():
        assert sha(ROOT/rel)==expected, 'Frozen dependency changed: '+Path(rel).name
    source=read(HERE/'prepared/SOURCE_FREEZE.json')
    for rel,expected in source['dependencies_sha256'].items():
        assert sha(ROOT/rel)==expected
    assert recipe['steps']==80 and recipe['microbatches_per_step']==2 and recipe['queries_per_microbatch']==4
    assert recipe['validation_steps']==[80] and recipe['source_policy']=='v9_retained_only_pristine_init'


def validation(encoder,data):
    began=time.monotonic()
    before=dict(encoder.usage)
    rows=[]
    validation_cases=[c for c in data['cases'] if c['split']=='val']
    with torch.inference_mode():
        for persona in sorted({c['persona'] for c in validation_cases}):
            indices=data['retained_indices'][persona]
            keys=[persona+':'+str(i) for i in indices]
            assert all(data['documents'][k]['split']=='val' for k in keys)
            documents=encoder.documents([data['documents'][k]['token_ids'] for k in keys])
            parents=[data['documents'][k]['parent_digest'] for k in keys]
            cases=[c for c in validation_cases if c['persona']==persona]
            queries=encoder.queries([c['token_ids'] for c in cases])
            for case,q in zip(cases,queries):
                scores=torch.stack([score_one(q,d) for d in documents]).cpu().numpy()
                assert scores.dtype==np.float64
                metrics=summarize_case(scores,indices,case['positive_indices'],parents,
                                       case['chunk_recall_denominator'],case['annotated_messages'])
                rows.append(dict(id=case['id'],persona=persona,**metrics,scores_original_index_order=scores.tolist()))
            del documents,queries
    assert len(rows)==64
    return dict(summary=aggregate(rows),rows=rows,wall_seconds=time.monotonic()-began,
                usage={k:int(encoder.usage[k]-before.get(k,0)) for k in encoder.usage})


def main(args):
    began=time.monotonic()
    check_lock(args.token,args.owner_pid)
    recipe=read(HERE/'RECIPE.json')
    verify(recipe)
    assert sys.version_info[:2]==(3,10) and torch.__version__==recipe['runtime']['torch']
    assert np.__version__==recipe['runtime']['numpy'] and __import__('transformers').__version__==recipe['runtime']['transformers']
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.use_deterministic_algorithms(True)
    torch.set_float32_matmul_precision('highest')
    assert torch.cuda.is_available()
    torch.manual_seed(recipe['seed'])
    torch.cuda.manual_seed_all(recipe['seed'])
    torch.cuda.reset_peak_memory_stats()
    out=HERE/recipe['output_name']
    out.mkdir(exist_ok=False)
    save(out/'START.json',dict(utc=datetime.now(timezone.utc).isoformat(),pid=os.getpid(),owner_pid=args.owner_pid,
         lock_token_sha256=hashlib.sha256(args.token.encode()).hexdigest(),recipe_sha256=sha(HERE/'RECIPE.json'),
         GPU=torch.cuda.get_device_name(),cuda=torch.version.cuda,python=sys.version))
    try:
        data=read(HERE/'prepared/DATA.json')
        schedule=read(HERE/'prepared/SCHEDULE.json')['rows']
        cases={c['id']:c for c in data['cases']}
        assert len(schedule)==160 and len(cases)==541
        loaded=time.monotonic()
        encoder=MetricEncoder(device='cuda:0',lock_token=args.token,owner_pid=args.owner_pid)
        torch.manual_seed(recipe['seed'])
        torch.cuda.manual_seed_all(recipe['seed'])
        encoder.inject()
        encoder.bert.requires_grad_(False)
        encoder.linear.requires_grad_(False)
        model_load_seconds=time.monotonic()-loaded
        baseline=validation(encoder,data)
        save(out/'baseline-validation.json',baseline)
        for n,p in encoder.bert.named_parameters():
            if n.endswith('.A') or n.endswith('.B'):
                p.requires_grad_(True)
        lora,projection=encoder.trainable()
        optimizer=torch.optim.AdamW([{'params':lora,'lr':recipe['optimizer']['lora_lr']},
                                    {'params':projection,'lr':recipe['optimizer']['projection_lr']}],
                                   betas=(.9,.999),eps=1e-8,weight_decay=.01,foreach=False,fused=False)
        training_began=time.monotonic()
        before=dict(encoder.usage)
        history=[]
        for step in range(1,81):
            check_lock(args.token,args.owner_pid)
            optimizer.zero_grad(set_to_none=True)
            losses=[]
            for micro in range((step-1)*2,step*2):
                row=schedule[micro]
                batch=[cases[i] for i in row['query_ids']]
                assert all(c['split']=='train' for c in batch)
                assert all(data['documents'][k]['split']=='train' for k in row['doc_keys'])
                q=encoder.queries([c['token_ids'] for c in batch])
                d=encoder.documents([data['documents'][k]['token_ids'] for k in row['doc_keys']])
                logits=torch.stack([torch.stack([score_one(query,doc) for doc in d]) for query in q])
                mask=torch.tensor(row['positive_mask'],dtype=torch.bool,device='cuda:0')
                value=positive_loss(logits,mask)
                assert torch.isfinite(value)
                (value/2).backward()
                losses.append(value.item())
                del q,d,logits,mask,value
            gradient=torch.nn.utils.clip_grad_norm_(lora+projection,1.0)
            assert torch.isfinite(gradient)
            assert all(p.grad is None for p in encoder.bert.parameters() if not p.requires_grad)
            optimizer.step()
            history.append(dict(step=step,loss=sum(losses)/2,gradient_norm=gradient.item()))
            if step%10==0:
                print(json.dumps(dict(stage='training',step=step,loss=sum(losses)/2,wall_seconds=time.monotonic()-training_began)),flush=True)
        torch.cuda.synchronize()
        training_seconds=time.monotonic()-training_began
        training_usage={k:int(encoder.usage[k]-before.get(k,0)) for k in encoder.usage}
        assert training_usage['query_encodings']==640 and training_usage['document_encodings']==1280
        assert training_usage['document_windows']==sum(x['document_windows'] for x in schedule)
        checkpoint=out/'adapter-step80.safetensors'
        adapter_sha=encoder.save(checkpoint,step=80,recipe_sha256=sha(HERE/'RECIPE.json'),prepared_sha256=sha(HERE/'prepared/RESULT.json'))
        sample=schedule[0]
        with torch.inference_mode():
            q=encoder.queries([cases[sample['query_ids'][0]]['token_ids']])[0]
            docs=encoder.documents([data['documents'][sample['doc_keys'][0]]['token_ids']])
            expected_q=q.cpu().clone()
            expected_d=docs[0].cpu().clone()
            expected_score=score_one(q,docs[0]).item()
        first_instance_usage=dict(encoder.usage)
        del q,docs,encoder,optimizer,lora,projection
        gc.collect()
        torch.cuda.empty_cache()
        loaded=time.monotonic()
        encoder=MetricEncoder(device='cuda:0',lock_token=args.token,owner_pid=args.owner_pid)
        encoder.load(checkpoint,adapter_sha,recipe_sha256=sha(HERE/'RECIPE.json'),prepared_sha256=sha(HERE/'prepared/RESULT.json'))
        reload_seconds=time.monotonic()-loaded
        with torch.inference_mode():
            q=encoder.queries([cases[sample['query_ids'][0]]['token_ids']])[0]
            docs=encoder.documents([data['documents'][sample['doc_keys'][0]]['token_ids']])
            assert torch.equal(expected_q,q.cpu()) and torch.equal(expected_d,docs[0].cpu())
            assert expected_score==score_one(q,docs[0]).item()
        learned=validation(encoder,data)
        save(out/'learned-validation.json',learned)
        gate=qualification(baseline['summary'],learned['summary'])
        old={r['id']:r for r in baseline['rows']}
        paired=[]
        for r in learned['rows']:
            a=old[r['id']]
            paired.append(dict(id=r['id'],persona=r['persona'],delta={m:float(r[m])-float(a[m]) for m in METRICS},
                               regressed_metrics=[m for m in METRICS if r[m]<a[m]],
                               baseline_top10=a['top10_original_indices'],learned_top10=r['top10_original_indices']))
        save(out/'paired-validation.json',dict(rows=paired))
        save(out/'training-history.json',dict(rows=history))
        verify(recipe)
        check_lock(args.token,args.owner_pid)
        result=dict(status='complete_fixed_step80_source_experiment',utc=datetime.now(timezone.utc).isoformat(),
                    selected_for_separate_final_answer_protocol=gate['passed'],source_gate=gate,
                    baseline=baseline['summary'],learned=learned['summary'],
                    paired={m:dict(Counter('up' if r['delta'][m]>0 else 'down' if r['delta'][m]<0 else 'equal' for r in paired)) for m in METRICS},
                    model_identity=dict(base_sha256=BASE_SHA,adapter_sha256=adapter_sha,features=FEATURES,unmerged=True,
                                        recipe_sha256=sha(HERE/'RECIPE.json'),prepared_sha256=sha(HERE/'prepared/RESULT.json')),
                    steps=80,microbatches=160,trainable_parameters=196608,save_reload_exact_probe=True,
                    costs=dict(total_wall_seconds=time.monotonic()-began,load_seconds=model_load_seconds,reload_seconds=reload_seconds,
                               training_seconds=training_seconds,baseline_validation_seconds=baseline['wall_seconds'],learned_validation_seconds=learned['wall_seconds'],
                               training_usage=training_usage,baseline_usage=baseline['usage'],learned_usage=learned['usage'],
                               first_instance_usage=first_instance_usage,second_instance_usage=dict(encoder.usage),
                               cuda_peak_allocated_mib=torch.cuda.max_memory_allocated()/1024**2,Answer_Judge_calls=0,monetary_cost=None),
                    benchmark_or_holdout_records_read=0,final_answer_scores_available=False,official_submission=False,
                    limitations='Source retrieval only. No benchmark score, native packing, rule/multievent protection or deployment qualification. Fixed shapes reduce arithmetic drift but do not claim cross-device bitwise equivalence.')
        save(out/'RESULT.json',result)
        save(out/'completion.json',dict(complete=True,result_sha256=sha(out/'RESULT.json')))
        print(json.dumps({k:result[k] for k in ['status','selected_for_separate_final_answer_protocol','source_gate','baseline','learned','paired','model_identity','costs']}),flush=True)
    except Exception as e:
        save(out/'error.json',dict(type=type(e).__name__,message=str(e)[:600],utc=datetime.now(timezone.utc).isoformat()))
        raise


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--token',required=True)
    parser.add_argument('--owner-pid',type=int,required=True)
    main(parser.parse_args())
