"""Freeze one complete recipe after CPU preparation and arithmetic preflight."""
from datetime import datetime,timezone
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
ROOT=BASE.parents[3]
sys.path.insert(0,str(ROOT/'models/qwen35_runtime'))
from metric_model import sha


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def main():
    prepared=read(HERE/'prepared/RESULT.json')
    assert read(HERE/'prepared/completion.json')['result_sha256']==sha(HERE/'prepared/RESULT.json')
    assert prepared['train_queries']==477 and prepared['validation_queries']==64 and not prepared['CUDA_initialized']
    for name,expected in prepared['files_sha256'].items():
        assert sha(HERE/'prepared'/name)==expected
    preflight=read(HERE/'preflight/RESULT.json')
    assert len(preflight['checks'])==6 and preflight['invalid_contracts_rejected']==4 and not preflight['CUDA_initialized']
    for name,expected in preflight['source_sha256'].items():
        assert sha(HERE/name)==expected
    main_completion=read(BASE/'corpus-index-v2/completion.json')
    assert main_completion['complete'] is True and main_completion['valid']==1152
    assert read(BASE/'corpus-index-v2/cooperative-exit.json')['completed'] is True
    assert read(BASE/'v2-diagnosis/call-ledger-audit.json')['status']=='complete_audit'
    projection=read(BASE/'rule-prefix-v3-prototype/DEVELOPMENT_SELECTION/RESULT.json')
    assert projection['status']=='complete_existing_grade_projection_not_fresh_candidate_scores' and projection['holdout_case_records_read']==0
    names=['prepare.py','metric_model.py','metrics.py','preflight.py','freeze.py','run.py','wait_and_run.py',
           'prepared/SOURCE_FREEZE.json','prepared/DATA.json','prepared/SCHEDULE.json','prepared/RESULT.json','prepared/completion.json','preflight/RESULT.json']
    paths=[HERE/n for n in names]+[BASE/'model_lock.py',BASE/'METRIC_SPACE_V29_DESIGN_NOTE.md']
    for p in [HERE/n for n in names if n.endswith('.py')]:
        compile(p.read_text(encoding='utf-8'),str(p),'exec')
    pins={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    recipe=dict(recipe_version=1,utc=datetime.now(timezone.utc).isoformat(),seed=20261031,output_name='run-step80',
                source_policy='v9_retained_only_pristine_init',dependencies_sha256=pins,
                source=dict(train_queries=477,validation_queries=64,train_chunks=7686,validation_chunks=2645,train_personas=24,validation_personas=8,
                            exclusion_policy='Existing v9 ledgers; raw source case/bank JSON parsed before filtering. No evaluation answers/options or holdout examples for training.',
                            source_limit='Exact/canonical exclusion cannot prove paraphrase or upstream pretraining independence.'),
                representation=dict(document_format='raw_body',query_positions=32,document_window=177,document_stride=145,
                                    backbone_adapter_projection_vectors='float32',dot_product='float32',maxsim_sum='float64',
                                    attention='eager',encoder_mode='eval_no_dropout_with_training_gradients',
                                    query_batch=4,document_window_batch=8,fixed_padding_with_discarded_dummy_rows=True,
                                    document_cache='none; no historical cache reused',adapter_deployment='unmerged'),
                trainable=dict(layers=[8,9,10,11],targets=['query','value'],rank=8,alpha=16,projection=True,parameters=196608),
                steps=80,microbatches_per_step=2,queries_per_microbatch=4,validation_steps=[80],
                optimizer=dict(name='AdamW',lora_lr=.0001,projection_lr=.00002,betas=[.9,.999],epsilon=1e-8,weight_decay=.01,
                               gradient_clip=1.,learning_rate_schedule='constant',foreach=False,fused=False),
                objective='Historical uniform multi-positive log-softmax across the eight scheduled documents; raw-body SHA-equivalent positives; differentiable FP64 score sum.',
                negatives='First8 fixed native BM25 retained same-persona nonpositive chunks excluding positive raw-body hashes. No model mining.',
                validation_gate=dict(MRR_gain_at_least=.01,nondecreasing=['chunk_recall10','chunk_parent_recall10','chunk_all_parents_hit','source_recall10','source_all_parents_hit']),
                selection='Only final step80; gate failure rejects; no epoch/LR/loss/step sweep. Pass only authorizes a separately frozen final-answer protocol.',
                prior_basis='v11 adapter/body/all32 improved MRR and recall. v24/v27 shared-query-weight failures motivate changing token metric parameterization. Historical weights are never loaded.',
                runtime={k:preflight[k] for k in ['python','numpy','torch','transformers']},
                resources='All CUDA operations in one child of public atomic-lock owner; no service or port required; only owner releases. Continue CPU while waiting.',
                prohibited='No benchmark/holdout training, official Smoke/Full, promotion, graph forest, global user facts, multiturn planning or benchmark settings changes.')
    with (HERE/'RECIPE.json').open('x',encoding='utf-8') as f:
        json.dump(recipe,f,indent=2)
        f.write('\n')
    print(json.dumps(dict(status='frozen_single_v29_recipe',recipe_sha256=sha(HERE/'RECIPE.json'),dependencies=len(pins),steps=80,validation_queries=64)))


if __name__=='__main__':
    main()
