"""Offline CPU preparation: fixed v9 sources, native BM25 and exact schedule."""
import ast
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import sys
import time
import unicodedata

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ROOT = BASE.parents[3]
OLD = ROOT / 'dist/sourcetrail-v500-full-history-20261017/adaptive_evidence'
SOURCE = ROOT / 'competition/runs/sourcetrail-colbert-full-history-20261017'
V9 = BASE / 'v2-diagnosis/training-source-isolation-v9'
V13 = BASE / 'v2-diagnosis/training-target-granularity-v13b'
FEATURES = BASE / 'query-gate-v16-readiness'
MODEL = ROOT / 'models/colbertv2.0'
OUT = HERE / 'prepared'
SEED = 20261031


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def write(p, value):
    with p.open('x', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')


def canonical(text):
    return hashlib.sha256(' '.join(unicodedata.normalize('NFC', text).split()).casefold().encode()).hexdigest()


def native_bm25():
    import numpy as np
    tree = ast.parse((OLD / 'core.py').read_text(encoding='utf-8'))
    nodes = [n for n in tree.body if
             (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'TOKEN' for t in n.targets)) or
             (isinstance(n, ast.FunctionDef) and n.name == 'tokens') or
             (isinstance(n, ast.ClassDef) and n.name == 'BM25')]
    assert len(nodes) == 3
    scope = dict(re=re, math=math, np=np, Counter=Counter, defaultdict=defaultdict)
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), 'frozen_native_bm25', 'exec'), scope)
    return scope['BM25']


def windows(raw):
    return max(1, 1 + math.ceil(max(0, len(raw) - 177) / 145))


def main():
    began = time.monotonic()
    assert sys.version_info[:2] == (3, 10)
    os.environ.update(CUDA_VISIBLE_DEVICES='-1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', TOKENIZERS_PARALLELISM='false')
    sys.path.insert(0, str(ROOT / 'models/qwen35_runtime'))
    import numpy as np
    import torch
    from transformers import AutoTokenizer
    assert not torch.cuda.is_initialized()
    old_plan = read(FEATURES / 'PLAN_FREEZE.json')
    for rel, expected in old_plan['dependencies_sha256'].items():
        assert sha(ROOT / rel) == expected
    paths = [SOURCE / n for n in ['training-cases.json', 'training-banks.json']]
    paths += [V9 / n for n in ['RESULT.json', 'QUERY_EXCLUSION_LEDGER.json', 'DOCUMENT_EXCLUSION_LEDGER.json']]
    paths += [V13 / n for n in ['RESULT.json', 'case-metadata.json']]
    paths += [FEATURES / n for n in ['PLAN_FREEZE.json', 'FEATURE_INDEX.json']]
    paths += [MODEL / n for n in ['model.safetensors', 'config.json', 'artifact.metadata', 'tokenizer.json', 'tokenizer_config.json', 'special_tokens_map.json', 'vocab.txt']]
    paths += [OLD / n for n in ['core.py', 'token_scorer.py', 'lora_adapter.py']]
    paths += [Path(__file__), BASE / 'METRIC_SPACE_V29_DESIGN_NOTE.md']
    pins = {p.relative_to(ROOT).as_posix(): sha(p) for p in paths}
    OUT.mkdir(exist_ok=False)
    write(OUT / 'SOURCE_FREEZE.json', dict(utc=datetime.now(timezone.utc).isoformat(), dependencies_sha256=pins,
          scope='v9 retained source-only preparation; no benchmark answer/options/holdout reads',
          exclusions='Existing v9 exact/canonical query, parent and chunk exclusions unchanged. No new filtering or label changes.',
          limitations='Canonical exact-match exclusions do not prove absence of paraphrase or upstream pretraining exposure.',
          raw_source_JSON_parsed_before_v9_filter=True, training_steps=0))
    tok = AutoTokenizer.from_pretrained(MODEL, local_files_only=True, trust_remote_code=False)
    banks = read(SOURCE / 'training-banks.json')
    original = {x['id']: x for x in read(SOURCE / 'training-cases.json')}
    qledger = [x for x in read(V9 / 'QUERY_EXCLUSION_LEDGER.json')['rows'] if x['retained']]
    dledger = [x for x in read(V9 / 'DOCUMENT_EXCLUSION_LEDGER.json')['rows'] if x['retained']]
    assert Counter(x['split'] for x in qledger) == Counter(train=477, val=64)
    assert Counter(x['split'] for x in dledger) == Counter(train=7686, val=2645)
    feature = {x['id']: x for x in read(FEATURES / 'FEATURE_INDEX.json')['rows']}
    provenance = read(V13 / 'RESULT.json')
    assert provenance['exact_bank_reconstruction'] and all(x['chunks_with_multiple_parents'] == 0 for x in provenance['lineage_counts'])
    metadata = {x['id']: x for x in read(V13 / 'case-metadata.json')}
    docs = {}
    retained = defaultdict(list)
    for row in dledger:
        p, i = row['persona'], row['original_index']
        d = banks[p][i]
        assert canonical(d['content']) == row['canonical_body_hash']
        key = p + ':' + str(i)
        raw = tok.encode(d['content'], add_special_tokens=False, verbose=False)
        docs[key] = dict(persona=p, original_index=i, split=row['split'], token_ids=raw,
                         raw_body_sha256=hashlib.sha256(d['content'].encode()).hexdigest(),
                         parent_digest=d['message'], windows=windows(raw))
        retained[p].append(i)
    retained = {p: sorted(indices) for p, indices in retained.items()}
    lexical = {p: native_bm25()([banks[p][i]['content'] for i in indices]) for p, indices in retained.items()}
    cases = []
    for row in sorted(qledger, key=lambda x: x['id']):
        c = original[row['id']]
        assert (c['persona'], c['split'], canonical(c['query'])) == (row['persona'], row['split'], row['canonical_query_hash'])
        p = c['persona']
        positive = sorted(row['remaining_original_positive_indices'])
        assert positive and set(positive) == set(c['positive_docs']) & set(retained[p])
        raw = tok.encode(c['query'], add_special_tokens=False, verbose=False)
        assert len(raw) <= 29 and not re.search(r'[\u3400-\u9fff\u3040-\u30ff\uac00-\ud7af]', c['query'])
        assert metadata[c['id']]['message_count_recoverable'] and metadata[c['id']]['all_parent_chunks_labeled_positive']
        positive_hashes = sorted({docs[p + ':' + str(i)]['raw_body_sha256'] for i in positive})
        negatives = []
        if c['split'] == 'train':
            order = np.argsort(-lexical[p].scores(c['query']), kind='stable')
            negatives = [retained[p][i] for i in order if retained[p][i] not in positive and
                         docs[p + ':' + str(retained[p][i])]['raw_body_sha256'] not in positive_hashes][:8]
            assert len(negatives) == 8
        denominator = max(1, len(c['positive_docs']) + c['missing_positive_messages'])
        assert denominator == feature[c['id']]['recall_denominator'] == metadata[c['id']]['frozen_chunk_recall_denominator']
        target_parents = {docs[p + ':' + str(i)]['parent_digest'] for i in positive}
        assert all((i in positive) == (docs[p + ':' + str(i)]['parent_digest'] in target_parents) for i in retained[p])
        cases.append(dict(id=c['id'], persona=p, split=c['split'], token_ids=raw,
                          canonical_query_hash=row['canonical_query_hash'], positive_indices=positive,
                          positive_body_hashes=positive_hashes, negative_indices=negatives,
                          chunk_recall_denominator=denominator, annotated_messages=metadata[c['id']]['annotated_messages']))
    train = [c for c in cases if c['split'] == 'train']
    val = [c for c in cases if c['split'] == 'val']
    assert len(train) == 477 and len(val) == 64 and len(docs) == 10331
    assert len({c['persona'] for c in train}) == 24 and len({c['persona'] for c in val}) == 8
    assert not ({c['persona'] for c in train} & {c['persona'] for c in val})
    rng = random.Random(SEED)
    order = list(range(len(train)))
    rng.shuffle(order)
    position = 0
    schedule = []
    for micro in range(160):
        batch = []
        for n in range(4):
            if position == len(order):
                rng.shuffle(order)
                position = 0
            c = train[order[position]]
            position += 1
            batch.append(c)
        keys = []
        for n, c in enumerate(batch):
            keys += [c['persona'] + ':' + str(c['positive_indices'][(micro+n) % len(c['positive_indices'])]),
                     c['persona'] + ':' + str(c['negative_indices'][(micro+n) % len(c['negative_indices'])])]
        mask = [[docs[k]['raw_body_sha256'] in c['positive_body_hashes'] for k in keys] for c in batch]
        assert all(any(row) and not all(row) for row in mask)
        assert all(docs[k]['split'] == 'train' for k in keys)
        count = sum(docs[k]['windows'] for k in keys)
        assert count <= 64
        schedule.append(dict(micro=micro, optimizer_step=micro//2+1, query_ids=[c['id'] for c in batch],
                             doc_keys=keys, positive_mask=mask, document_windows=count))
    write(OUT / 'DATA.json', dict(cases=cases, documents=docs, retained_indices=retained,
                                special_ids={n: getattr(tok, n+'_token_id') for n in ['cls', 'sep', 'mask', 'pad']},
                                punctuation=sorted({tok.encode(p, add_special_tokens=False)[0] for p in __import__('string').punctuation})))
    write(OUT / 'SCHEDULE.json', dict(seed=SEED, train_order='case_id_sorted_before_shuffle',
                                   positive_rule='(micro+n) modulo retained positive count',
                                   negative_rule='(micro+n) modulo first8 native BM25 retained same-persona nonpositive raw-body hashes', rows=schedule))
    for rel, expected in pins.items():
        assert sha(ROOT / rel) == expected
    result = dict(status='complete_CPU_source_and_schedule_preparation', seed=SEED,
                  train_queries=477, validation_queries=64, train_chunks=7686, validation_chunks=2645,
                  optimizer_steps_planned=80, microbatches=160, gradient_query_presentations_planned=640,
                  unique_training_queries_scheduled=len({i for x in schedule for i in x['query_ids']}),
                  max_micro_windows=max(x['document_windows'] for x in schedule),
                  scheduled_document_encodings=sum(len(x['doc_keys']) for x in schedule),
                  scheduled_document_windows=sum(x['document_windows'] for x in schedule),
                  CPU_wall_seconds=time.monotonic()-began, CUDA_initialized=torch.cuda.is_initialized(),
                  training_steps=0, encoder_Answer_Judge_calls=0, evaluation_record_reads=0,
                  files_sha256={n: sha(OUT/n) for n in ['SOURCE_FREEZE.json', 'DATA.json', 'SCHEDULE.json']})
    write(OUT / 'RESULT.json', result)
    write(OUT / 'completion.json', dict(complete=True, result_sha256=sha(OUT/'RESULT.json')))
    print(json.dumps(result))


if __name__ == '__main__':
    main()
