"""Stable chunk and parent-message metrics; original denominators retained."""
import numpy as np


def summarize_case(scores, indices, positive_indices, parents, chunk_denominator, annotated_messages):
    scores = np.asarray(scores)
    if scores.dtype != np.float64 or scores.shape != (len(indices),) or not np.isfinite(scores).all():
        raise ValueError('Complete finite FP64 scores required')
    positive = set(positive_indices)
    target = {p for i,p in zip(indices,parents) if i in positive}
    if not target or not all((i in positive)==(p in target) for i,p in zip(indices,parents)):
        raise ValueError('Positive parent mapping incomplete')
    order = np.argsort(-scores,kind='stable').tolist()
    top = order[:10]
    ranks = [r for r,pos in enumerate(order,1) if indices[pos] in positive]
    parent_hits = {parents[pos] for pos in top} & target
    champions = {}
    for pos,p in enumerate(parents):
        if p not in champions or scores[pos]>scores[champions[p]]:
            champions[p] = pos
    source_order = sorted(champions,key=lambda p:(-float(scores[champions[p]]),champions[p]))
    source_ranks = [r for r,p in enumerate(source_order,1) if p in target]
    hits = set(source_order[:10]) & target
    return dict(chunk_MRR=1/min(ranks),chunk_recall10=len({indices[i] for i in top}&positive)/chunk_denominator,
                chunk_parent_recall10=len(parent_hits)/annotated_messages,
                chunk_all_parents_hit=len(parent_hits)==annotated_messages,
                source_MRR=1/min(source_ranks),source_recall10=len(hits)/annotated_messages,
                source_all_parents_hit=len(hits)==annotated_messages,
                top10_original_indices=[indices[i] for i in top],source_top10_parent_digests=source_order[:10],
                best_positive_rank=min(ranks),chunk_top10_distinct_sources=len({parents[i] for i in top}),
                source_boundary_tie=bool(len(source_order)>10 and scores[champions[source_order[9]]]==scores[champions[source_order[10]]]))


METRICS = ('chunk_MRR','chunk_recall10','chunk_parent_recall10','chunk_all_parents_hit',
           'source_MRR','source_recall10','source_all_parents_hit')


def aggregate(rows):
    assert len(rows)==64
    return {m:sum(float(x[m]) for x in rows)/64 for m in METRICS}


def qualification(baseline, learned):
    tests = {'chunk_MRR_gain_at_least_0.01':learned['chunk_MRR']>=baseline['chunk_MRR']+.01}
    for m in ('chunk_recall10','chunk_parent_recall10','chunk_all_parents_hit','source_recall10','source_all_parents_hit'):
        tests[m+'_nondecreasing'] = learned[m]>=baseline[m]
    return dict(passed=all(tests.values()),conditions=tests)
