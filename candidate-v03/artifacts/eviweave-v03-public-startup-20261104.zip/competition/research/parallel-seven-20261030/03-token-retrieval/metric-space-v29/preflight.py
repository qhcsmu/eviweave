"""CPU arithmetic, gradient, window and zero-adapter contract checks."""
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import sys
import time

os.environ.update(CUDA_VISIBLE_DEVICES='-1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parents[3]
sys.path.insert(0,str(ROOT/'models/qwen35_runtime'))
import numpy as np
import torch
from metric_model import MetricEncoder,LoRALinear,document_windows,query_window,score_one,positive_loss,sha
from metrics import summarize_case,qualification


def main():
    began=time.monotonic()
    assert sys.version_info[:2]==(3,10)
    torch.set_num_threads(2)
    torch.manual_seed(20261031)
    checks=[]
    special=dict(cls=101,sep=102,mask=103,pad=0)
    assert [len(document_windows(list(range(n)),special)) for n in (0,177,178,322,323)]==[1,1,2,2,3]
    assert document_windows(list(range(178)),special)[1][2:-1]==list(range(145,178))
    ids,attention=query_window([7,8],special)
    assert len(ids)==len(attention)==32 and ids[:5]==[101,1,7,8,102] and sum(attention)==5
    checks.append('native177/145_windows_and_all32_masked_query_layout')
    q=torch.randn(32,128,requires_grad=True)
    d=torch.randn(17,128,requires_grad=True)
    s=score_one(q,d)
    ref=(d.detach().numpy()@q.detach().numpy().T).max(0).astype(np.float64).sum()
    assert abs(s.item()-ref)<1e-4 and s.dtype==torch.float64
    s.backward()
    assert torch.isfinite(q.grad).all() and torch.isfinite(d.grad).all() and q.grad[31].abs().sum()>0
    checks.append('FP32_dot_FP64_complete32_sum_finite_gradient')
    layer=LoRALinear(torch.nn.Linear(8,8))
    x=torch.randn(4,8)
    assert torch.equal(layer(x),layer.base(x))
    layer(x).square().sum().backward()
    assert layer.B.grad.abs().sum()>0 and layer.base.weight.grad is None
    checks.append('unmerged_zero_LoRA_identity_and_frozen_base_gradient')
    logits=torch.tensor([[2.,1.,0.],[0.,1.,2.]],dtype=torch.float64,requires_grad=True)
    mask=torch.tensor([[True,True,False],[False,False,True]])
    loss=positive_loss(logits,mask)
    expected=-(torch.log_softmax(logits,1)[0,:2].mean()+torch.log_softmax(logits,1)[1,2])/2
    assert torch.equal(loss,expected)
    loss.backward()
    assert torch.isfinite(logits.grad).all()
    checks.append('equivalent_body_multipositive_loss_gradient')
    m=summarize_case(np.asarray([1.,1.,0.],dtype=np.float64),[10,11,12],[12],['a','a','b'],2,2)
    assert m['top10_original_indices']==[10,11,12] and m['chunk_MRR']==1/3 and m['source_MRR']==.5 and m['chunk_parent_recall10']==.5
    checks.append('stable_ties_distinct_source_and_unchanged_missing_denominators')
    rejected=0
    for call in [lambda:query_window(list(range(30)),special),lambda:score_one(q.double(),d),
                 lambda:positive_loss(logits,torch.ones_like(mask)),
                 lambda:summarize_case(np.ones(3,np.float32),[0,1,2],[0],['a','b','c'],1,1)]:
        try:
            call()
        except ValueError:
            rejected+=1
    assert rejected==4
    encoder=MetricEncoder()
    tokens=[encoder.tokenizer.encode('When did the project move?',add_special_tokens=False)]
    bodies=[encoder.tokenizer.encode('The project moved to a new office in June.',add_special_tokens=False)]
    with torch.inference_mode():
        q0=encoder.queries(tokens)[0].clone()
        d0=encoder.documents(bodies)[0].clone()
    encoder.inject()
    with torch.inference_mode():
        q1=encoder.queries(tokens)[0]
        d1=encoder.documents(bodies)[0]
    assert torch.equal(q0,q1) and torch.equal(d0,d1) and torch.equal(score_one(q0,d0),score_one(q1,d1))
    lora,projection=encoder.trainable()
    assert sum(p.numel() for p in lora+projection)==196608
    assert encoder.bert.config._attn_implementation=='eager' and not torch.cuda.is_initialized()
    checks.append('pristine_real_encoder_zero_adapter_exact_identity_196608_parameters')
    out=HERE/'preflight'
    out.mkdir(exist_ok=False)
    result=dict(status='complete_CPU_preflight',utc=datetime.now(timezone.utc).isoformat(),checks=checks,
                invalid_contracts_rejected=rejected,synthetic_real_encoder_queries=2,synthetic_real_encoder_documents=2,
                CUDA_initialized=False,training_steps=0,benchmark_or_holdout_records_read=0,
                CPU_wall_seconds=time.monotonic()-began,python=sys.version,numpy=np.__version__,torch=torch.__version__,
                transformers=__import__('transformers').__version__,
                source_sha256={n:sha(HERE/n) for n in ['preflight.py','metric_model.py','metrics.py']})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))


if __name__=='__main__':
    main()
