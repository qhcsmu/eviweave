"""Atomic public lock owner launches one private child; never steals a lock."""
from datetime import datetime,timezone
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
ROOT=BASE.parents[3]


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def main():
    out=HERE/'resource-owner'
    out.mkdir(exist_ok=False)
    began=time.monotonic()
    write(out/'START.json',dict(pid=os.getpid(),utc=datetime.now(timezone.utc).isoformat(),scope='single frozen source experiment; no services'))
    spec=importlib.util.spec_from_file_location('metric29_public_lock',BASE/'model_lock.py')
    lock_module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lock_module)
    lock_module.RUN=HERE
    lock=None
    acquired=False
    while not acquired:
        if (HERE/'STOP_REQUESTED').exists():
            write(out/'EXIT.json',dict(stopped_before_acquisition=True,pid=os.getpid()))
            return
        try:
            lock=lock_module.ModelLock()
            lock.__enter__()
            acquired=True
        except RuntimeError:
            if not lock_module.LOCK.exists():
                raise
            write(out/'WAITING.json',dict(pid=os.getpid(),utc=datetime.now(timezone.utc).isoformat(),waiting_seconds=time.monotonic()-began,
                                        status='another owner holds public lock; no GPU initialized'))
            print(json.dumps(dict(stage='waiting_public_lock',seconds=round(time.monotonic()-began,1))),flush=True)
            for _ in range(30):
                if (HERE/'STOP_REQUESTED').exists():
                    break
                time.sleep(1)
    try:
        write(out/'ACQUIRED.json',dict(**lock.owner,waiting_seconds=time.monotonic()-began))
        command=[sys.executable,'-B','-X','utf8',str(HERE/'run.py'),'--token',lock.token,'--owner-pid',str(os.getpid())]
        with (out/'child.stdout.log').open('xb') as stdout,(out/'child.stderr.log').open('xb') as stderr:
            child=subprocess.Popen(command,cwd=str(ROOT),stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
            write(out/'CHILD.json',dict(pid=child.pid,parent_pid=os.getpid(),utc=datetime.now(timezone.utc).isoformat()))
            while child.poll() is None:
                lock.assert_owned()
                if (HERE/'STOP_REQUESTED').exists():
                    child.terminate()
                    child.wait()
                    break
                time.sleep(1)
            code=child.wait()
        write(out/'CHILD_EXIT.json',dict(exit_code=code,utc=datetime.now(timezone.utc).isoformat()))
    finally:
        # A live child may retain CUDA allocations. End our child before release.
        if 'child' in locals() and child.poll() is None:
            child.terminate()
            child.wait()
        lock.__exit__(None,None,None)
        write(out/'CLEANUP.json',dict(own_child_exited=True,own_public_lock_released=True,services_started=0,
                                    utc=datetime.now(timezone.utc).isoformat(),total_wall_seconds=time.monotonic()-began))
    if code:
        raise SystemExit(code)
    print(json.dumps(dict(stage='complete',own_lock_released=True,exit_code=code)),flush=True)


if __name__=='__main__':
    main()
