# v29: learn the token similarity space

Preparation note, 2026-10-31. This is not a frozen training recipe, a selected
candidate, or a final-answer result.

The two shared query-weight objectives (v24 and v27) improved first-positive
rank but reduced independent-source coverage. Stop that parameter sweep. The
v11 fixed historical adapter comparison improved both chunk MRR and recall
under body/all32, which motivates a different parameterization: a small token
metric adapter. The historical adapter cannot initialize this experiment:
v9 found two training-query overlaps with the current evaluation cohort.

Start from the pristine ColBERT base, retain only the frozen v9 train477 and
validation64 sources, and preserve the original annotation denominators. Do
not open benchmark answers, choices, grading or holdout records to prepare it.
Use raw bodies, all 32 query positions, native 177/145 document windows, and
the original punctuation mask. Use FP32 backbone/adapter/document vectors and
dot products, then FP64 MaxSim summation in both training and inference. Keep
LoRA unmerged at deployment. Do not reuse CPU/FP16 or historical adapter caches.

The intended finite experiment is last-four-layer query/value LoRA rank8,
alpha16 plus the projection (196608 trainable parameters), 80 optimizer
updates, two four-query microbatches per update. Freeze exact v9-filtered
BM25 negatives, token IDs, raw-body equivalence and all 160 microbatches before
training. Historical optimizer settings are a starting justification, not a
claim to reproduce the historical BF16/role-prefixed experiment.

Validate only the final step80 against a new pristine control with the same
representation. Require MRR gain >= .01 and nondecreasing chunk recall,
top10-chunk parent recall/full-support rate, and distinct-source recall/full
support rate. Preserve every validation regression. A source pass permits a
separate frozen final-answer protocol; it does not establish final-answer gain.
Document/rule/multievent protection remains an unresolved integration task.

All GPU operations require the public atomic directory lock and recorded
ownership; never steal it or stop another service. Wait using CPU work. No
Smoke, Full, incumbent change, graph forest, global-user-fact mechanism or
multiturn planner. All files stay under direction03 except the public lock.
